// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // Check if the collection pointer is created and not null
    ASSERT_TRUE(collection) << "Collection smart pointer should not be null";
    ASSERT_NE(collection.get(), nullptr) << "Collection pointer should not be null";
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // Define the initial size
    const int initialSize = 0;

    // Check if the collection is empty
    ASSERT_TRUE(collection->empty()) << "Collection should be empty when created";
    ASSERT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " when created";
}

// Test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // Define the initial size and number of entries to add
    const int initialSize = 0;
    const int numEntries = 1;

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Add a single entry to the collection
    add_entries(numEntries);

    // Check if the collection is no longer empty
    ASSERT_FALSE(collection->empty()) << "Collection should not be empty after adding one entry";
    ASSERT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " after adding one entry";
}

// Test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Define the initial size and number of entries to add
    const int initialSize = 0;
    const int numEntries = 5;

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Add five entries to the collection
    add_entries(numEntries);

    // Check if the collection is no longer empty
    ASSERT_FALSE(collection->empty()) << "Collection should not be empty after adding five entries";
    ASSERT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " after adding five entries";
}

// Test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize)
{
    // Define the initial size and number of entries to add for each iteration
    const int initialSize = 0;
    std::vector<int> numEntriesArr = { 1, 5, 10 };

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Check that max_size is at least as large as initialSize
    ASSERT_GE(collection->max_size(), collection->size()) << "max_size should be at least as large as size " << initialSize;

    for (int numEntries : numEntriesArr)
    {
        // Clear the collection
        collection->clear();

        // Add numEntries entries to the collection
        add_entries(numEntries);

        // Check that max_size is at least as large as size
        ASSERT_GE(collection->max_size(), collection->size()) << "max_size should be at least as large as size " << numEntries;
    }
}

// Test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize)
{
    // Define the initial size and number of entries to add for each iteration
    const int initialSize = 0;
    std::vector<int> numEntriesArr = { 1, 5, 10 };

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Check that capacity is at least as large as initialSize
    ASSERT_GE(collection->capacity(), collection->size()) << "capacity should be at least as large as size " << initialSize;

    for (int numEntries : numEntriesArr)
    {
        // Clear the collection
        collection->clear();

        // Add numEntries entries to the collection
        add_entries(numEntries);

        // Check that capacity is at least as large as size
        ASSERT_GE(collection->capacity(), collection->size()) << "capacity should be at least as large as size " << numEntries;
    }
}

// Test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesSize)
{
    // Define the initial and new sizes for resizing
    const int initialSize = 0;
    const int newSize = 10;

    // Expect the collection to be empty before resizing
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before resizing";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before resizing";

    // Resize the collection to the new size
    collection->resize(newSize);

    // Verify the size has increased
    ASSERT_EQ(collection->size(), newSize) << "Collection size should be " << newSize << " after resizing";
}

// Test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesSize)
{
    // Define the initial size, number of entries to add, and reduces size for resizing
    const int initialSize = 0;
    const int numEntries = 10;
    const int reducedSize = 5;

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Add numEntries entries to the collection
    add_entries(numEntries);

    // Verify the collection has the correct new size
    EXPECT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " before resizing";

    // Resize the collection to the reduced size
    collection->resize(reducedSize);

    // Verify the size has decreased
    ASSERT_EQ(collection->size(), reducedSize) << "Collection size should be " << reducedSize << " after resizing";
}

// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero)
{
    // Define the initial size and number of entries to add
    const int initialSize = 0;
    const int numEntries = 10;

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Add numEntries entries to the collection
    add_entries(numEntries);

    // Verify the collection has the correct new size
    EXPECT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " before resizing to zero";

    // Resize the collection to the initial size of 0
    collection->resize(initialSize);

    // Verify the size has decreased to zero
    ASSERT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " after resizing to zero";

    // Verify the collection is empty
    ASSERT_TRUE(collection->empty()) << "Collection should be empty after resizing to zero";
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Define the initial size and number of entries to add
    const int initialSize = 0;
    const int numEntries = 10;

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Add numEntries entries to the collection
    add_entries(numEntries);

    // Verify the collection has the correct number of elements
    EXPECT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " before clearing";

    // Clear the collection
    collection->clear();

    // Verify the size is now the initial size
    ASSERT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " after clearing";

    // Verify that the collection is empty
    ASSERT_TRUE(collection->empty()) << "Collection should be empty after clearing";
}

// Test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseRange)
{
    // Define the initial size, the new size, and the range to erase
    const int initialSize = 0;
    const int numEntries = 10;
    const int eraseStart = 3;
    const int eraseEnd = 7;

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Add numEntries entries to the collection
    add_entries(numEntries);

    // Verify the collection has the correct initial number of elements
    EXPECT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " before erasing";

    // Erase elements from index eraseStart to eraseEnd (exclusive)
    collection->erase(collection->begin() + eraseStart, collection->begin() + eraseEnd);

    // Verify the number of elements remaining
    ASSERT_EQ(collection->size(), numEntries - (eraseEnd - eraseStart)) << "Collection size should be reduced by " << (eraseEnd - eraseStart) << " after erasing";
}

// Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    // Define the initial size, the number of entries to add, and the space to reserve
    const int initialSize = 0;
    const int numEntries = 10;
    const int reserveSize = 10000;
    int initialCapacity = 0;

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Add numEntries entries to the collection
    add_entries(numEntries);

    // Verify the collection has the correct number of elements
    EXPECT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " before reserving capacity";

    // Get initial reserve size from the capacity
    initialCapacity = collection->capacity();

    // Verify that the reserve size will result in an increased capacity
    ASSERT_GE(reserveSize, initialCapacity) << "Collection initial capacity should be less than the reserve size";

    // Reserve more capacity than the current size
    collection->reserve(reserveSize);

    // Verify the size has not changed
    ASSERT_EQ(collection->size(), numEntries) << "Collection size should remain the same after reserving capacity";

    // Verify the capacity has increased to or past the reserve size
    ASSERT_GE(collection->capacity(), reserveSize) << "Collection capacity should increase after reserving capacity";
}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, AtThrowsOutOfRangeException)
{
    // Define the number of elements to add
    const int initialSize = 0;
    const int numEntries = 5;

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Add numEntries entries to the collection
    add_entries(numEntries);

    // Verify the collection has the correct number of elements
    EXPECT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " before accessing out of bounds with at()";

    // Attempt to access an out-of-bounds index
    ASSERT_THROW({
        auto _ = collection->at(collection->size());
        }, std::out_of_range) << "Expected std::out_of_range exception not thrown";
}

// Test to verify push_back correctly adds elements to the vector
TEST_F(CollectionTest, PushBackAddsElements)
{
    // Define the number of elements to add
    const int initialSize = 0;
    const int numEntries = 10;

    // Expect the collection to be empty before pushing back entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before pushing back entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before pushing back entries";

    // Push back numEntries entries to the collection
    for (int i = 0; i < numEntries; ++i)
    {
        collection->push_back(i);
    }

    // Verify the collection size
    ASSERT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " after adding elements";

    // Verify the elements are correctly added
    for (int i = 0; i < numEntries; ++i)
    {
        EXPECT_EQ(collection->at(i), i) << "Element at index " << i << " should be " << i;
    }
}

// Test to verify accessing out-of-bounds index with [] does not throw exception (undefined behavior)
TEST_F(CollectionTest, AccessOutOfBoundsWithOperatorBrackets)
{
    // Define the number of elements to add
    const int initialSize = 0;
    const int numEntries = 5;

    // Expect the collection to be empty before adding entries
    EXPECT_TRUE(collection->empty()) << "Collection should be empty before adding entries";
    EXPECT_EQ(collection->size(), initialSize) << "Collection size should be " << initialSize << " before adding entries";

    // Add numEntries entries to the collection
    add_entries(numEntries);

    // Verify the collection size
    EXPECT_EQ(collection->size(), numEntries) << "Collection size should be " << numEntries << " before accessing out of bounds with []";

    // Attempt to access an out-of-bounds index using operator[]
    ASSERT_DEATH({
        volatile int value = (*collection)[collection->size()];
        }, ".*") << "Accessing out-of-bounds index with operator[] should not throw an exception but results in undefined behavior";
}
