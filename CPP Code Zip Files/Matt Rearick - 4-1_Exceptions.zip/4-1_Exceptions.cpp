// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

/*
* My Custom Exception for custom exception issues; derrived from std::exception.
*/
class CustomException : public std::exception
{
public:
    CustomException(const std::string& message) : msg_(message) {}

    const char* what() const noexcept override
    {
        return msg_.c_str();
    }

private:
    std::string msg_;
};

bool do_even_more_custom_application_logic()
{
    // Throw a standard exception with a custom message
    throw std::logic_error("Standard exception in do_even_more_custom_application_logic.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        // Wrap the call to do_even_more_custom_application_logic() with exception handling
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        // Catching and displaying the standard exception
        std::cerr << "Caught std::exception: " << e.what() << std::endl;
    }

    // Throwing a custom exception with a custom message
    throw CustomException("Custom exception thrown in do_custom_application_logic.");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    if (den == 0)
    {
        // Throwing a standard exception with a custom message
        throw std::range_error("Divide by zero error in divide function.");
    }
    return (num / den);
}

void do_division() noexcept
{
    try
    {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::range_error& e)
    {
        // Handling 'range_error' exception specifically for divide errors
        std::cerr << "Caught range_error: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e)
    {
        // Handling the custom exception with custom message
        std::cerr << "Caught CustomException: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        // Handling standard exceptions with custom message
        std::cerr << "Caught std::exception: " << e.what() << std::endl;
    }
    catch (...)
    {
        // Handling any uncaught exceptions
        std::cerr << "Caught unknown exception." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu