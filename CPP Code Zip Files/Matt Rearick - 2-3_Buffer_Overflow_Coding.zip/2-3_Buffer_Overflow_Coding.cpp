// 2-3_Buffer_Overflow_Coding.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

/* Provides a main test method to prevent a buffer overflow from overwriting an unintended variable. */
int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

    const std::string account_number = "CharlieBrown42";
    char user_input[21]; // Increase size by 1 to accommodate null terminator

    std::cout << "Enter a value: ";

    // Use getline to read up to sizeof(user_input) - 1 characters and adds null terminator
    std::cin.getline(user_input, sizeof(user_input));

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
